Połączony resource pack: Frajernia + Kukurydza
Minecraft Java 26.2
Zmienia: Totem Nieśmiertelności oraz obraz burning_skull.
